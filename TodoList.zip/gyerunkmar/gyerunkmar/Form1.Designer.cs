﻿namespace TodoList
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.addButton = new System.Windows.Forms.Button();
            this.deleteButton = new System.Windows.Forms.Button();
            this.completeButton = new System.Windows.Forms.Button();
            this.dueDatePicker = new System.Windows.Forms.DateTimePicker();
            this.taskListBox = new System.Windows.Forms.ListBox();
            this.taskTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // addButton
            // 
            this.addButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.addButton.Location = new System.Drawing.Point(12, 88);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(200, 33);
            this.addButton.TabIndex = 0;
            this.addButton.Text = " Hozzáadás";
            this.addButton.UseVisualStyleBackColor = false;
            this.addButton.Click += new System.EventHandler(this.addButton_Click_1);
            // 
            // deleteButton
            // 
            this.deleteButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.deleteButton.Location = new System.Drawing.Point(588, 319);
            this.deleteButton.Name = "deleteButton";
            this.deleteButton.Size = new System.Drawing.Size(200, 39);
            this.deleteButton.TabIndex = 1;
            this.deleteButton.Text = " Törlés";
            this.deleteButton.UseVisualStyleBackColor = false;
            this.deleteButton.Click += new System.EventHandler(this.deleteButton_Click_1);
            // 
            // completeButton
            // 
            this.completeButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.completeButton.Location = new System.Drawing.Point(12, 161);
            this.completeButton.Name = "completeButton";
            this.completeButton.Size = new System.Drawing.Size(200, 36);
            this.completeButton.TabIndex = 2;
            this.completeButton.Text = " Befejezése";
            this.completeButton.UseVisualStyleBackColor = false;
            this.completeButton.Click += new System.EventHandler(this.completeButton_Click_1);
            // 
            // dueDatePicker
            // 
            this.dueDatePicker.Location = new System.Drawing.Point(588, 29);
            this.dueDatePicker.Name = "dueDatePicker";
            this.dueDatePicker.Size = new System.Drawing.Size(200, 20);
            this.dueDatePicker.TabIndex = 3;
            this.dueDatePicker.Value = new System.DateTime(2024, 9, 4, 12, 39, 48, 0);
            this.dueDatePicker.ValueChanged += new System.EventHandler(this.dueDatePicker_ValueChanged);
            // 
            // taskListBox
            // 
            this.taskListBox.FormattingEnabled = true;
            this.taskListBox.Location = new System.Drawing.Point(250, 29);
            this.taskListBox.Name = "taskListBox";
            this.taskListBox.Size = new System.Drawing.Size(314, 329);
            this.taskListBox.TabIndex = 4;
            // 
            // taskTextBox
            // 
            this.taskTextBox.Location = new System.Drawing.Point(12, 29);
            this.taskTextBox.Name = "taskTextBox";
            this.taskTextBox.Size = new System.Drawing.Size(200, 20);
            this.taskTextBox.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.taskTextBox);
            this.Controls.Add(this.taskListBox);
            this.Controls.Add(this.dueDatePicker);
            this.Controls.Add(this.completeButton);
            this.Controls.Add(this.deleteButton);
            this.Controls.Add(this.addButton);
            this.Name = "Form1";
            this.Text = "TodoList";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.Button deleteButton;
        private System.Windows.Forms.Button completeButton;
        private System.Windows.Forms.DateTimePicker dueDatePicker;
        private System.Windows.Forms.ListBox taskListBox;
        private System.Windows.Forms.TextBox taskTextBox;
    }
}

